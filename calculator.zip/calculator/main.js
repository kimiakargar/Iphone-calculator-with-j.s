let displayy = document.querySelector(".display");

function showDisplay (event) {
const y = event.target.innerText;
if( displayy.innerHTML == 0){
    return displayy.innerHTML = y;
}
return displayy.innerHTML += y;

}
function calculate (){
    let natije = displayy.innerText;
    displayy.innerText = eval(natije);
}

function pakkon (){
    displayy.innerText=0;
}


function clear() {
    let text = displayy.innerText;
    if (text.length === 1) {
        displayy.innerText = 0;
    } else { 
        displayy.innerText = text.substring(0, text.length - 1)
    }
}




let list = document.querySelectorAll(".show-display");
list.forEach(item => {
    item.addEventListener("click", showDisplay
    )
})

document.querySelector(".calculate").addEventListener("click", calculate);

document.querySelector(".all-clear").addEventListener("click", pakkon);

document.querySelector(".clear-last").addEventListener("click", clear);